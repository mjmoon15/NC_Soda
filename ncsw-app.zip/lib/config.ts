/**
 * Central runtime config + demo-mode detection.
 *
 * The whole app is designed to run with NO Supabase project attached:
 * when the env vars below are missing we fall back to seed/mock data and a
 * cookie-based "demo" auth so the UI is fully explorable via `npm run dev`.
 */

export const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
export const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "";
export const SUPABASE_SERVICE_ROLE_KEY =
  process.env.SUPABASE_SERVICE_ROLE_KEY ?? "";

/** True only when a real Supabase project is wired up. */
export const isSupabaseConfigured = Boolean(SUPABASE_URL && SUPABASE_ANON_KEY);

/** Inverse helper for readability at call sites. */
export const isDemoMode = !isSupabaseConfigured;

export const SITE = {
  name: "New Creation Soda Works",
  shortName: "New Creation",
  tagline: "Real ingredients. Joyful fizz.",
} as const;

/**
 * Data access layer. Every read goes through here so surfaces never branch on
 * demo-vs-real themselves: when Supabase is unconfigured we serve seed data
 * from ./mock; otherwise we query Postgres (RLS enforces who sees what).
 *
 * DB column contract (snake_case) is mirrored by the mappers below — the SQL
 * migration must match these column names exactly.
 */
import { isSupabaseConfigured } from "@/lib/config";
import type { Asset, Product, Video } from "@/lib/types";
import * as mock from "./mock";

/* ── row mappers (snake_case DB row -> camelCase domain type) ───────── */

type Row = Record<string, unknown>;

function mapProduct(r: Row): Product {
  return {
    id: String(r.id),
    slug: String(r.slug),
    name: String(r.name),
    tagline: String(r.tagline ?? ""),
    description: String(r.description ?? ""),
    category: r.category as Product["category"],
    color: String(r.color ?? "#2E8B54"),
    imageUrl: String(r.image_url ?? ""),
    calories: Number(r.calories ?? 0),
    isGlutenFree: Boolean(r.is_gluten_free),
    featured: Boolean(r.featured),
    sku: String(r.sku ?? ""),
    upc: String(r.upc ?? ""),
    caseUpc: String(r.case_upc ?? ""),
    casePack: Number(r.case_pack ?? 0),
    unitVolume: String(r.unit_volume ?? ""),
    netWeight: String(r.net_weight ?? ""),
    abv: r.abv ? String(r.abv) : undefined,
    ingredients: String(r.ingredients ?? ""),
    shelfLifeDays: Number(r.shelf_life_days ?? 0),
  };
}

function mapVideo(r: Row): Video {
  return {
    id: String(r.id),
    title: String(r.title),
    description: String(r.description ?? ""),
    category: r.category as Video["category"],
    access: r.access as Video["access"],
    youtubeId: r.youtube_id ? String(r.youtube_id) : undefined,
    storagePath: r.storage_path ? String(r.storage_path) : undefined,
    thumbnailUrl: String(r.thumbnail_url ?? ""),
    durationSeconds: Number(r.duration_seconds ?? 0),
  };
}

function mapAsset(r: Row): Asset {
  return {
    id: String(r.id),
    title: String(r.title),
    description: String(r.description ?? ""),
    type: r.type as Asset["type"],
    fileUrl: String(r.file_url ?? "#"),
    fileType: String(r.file_type ?? ""),
    sizeBytes: Number(r.size_bytes ?? 0),
    productSlug: r.product_slug ? String(r.product_slug) : undefined,
    access: "rep",
  };
}

/* ── products ──────────────────────────────────────────────────────── */

/**
 * PUBLIC catalog read. In real mode this hits the `public_products` VIEW, which
 * exposes only public-safe columns (no SKU/UPC) — gated specs come back empty.
 * Use getRepProducts() for the full, rep-gated spec data.
 */
export async function getProducts(): Promise<Product[]> {
  if (!isSupabaseConfigured) return mock.products;
  const { createServerSupabase } = await import("@/lib/supabase/server");
  const supabase = await createServerSupabase();
  const { data } = await supabase
    .from("public_products")
    .select("*")
    .order("name");
  return (data ?? []).map(mapProduct);
}

export async function getFeaturedProducts(): Promise<Product[]> {
  return (await getProducts()).filter((p) => p.featured);
}

/** PUBLIC single-product read (public-safe columns only in real mode). */
export async function getProduct(slug: string): Promise<Product | null> {
  if (!isSupabaseConfigured) {
    return mock.products.find((p) => p.slug === slug) ?? null;
  }
  const { createServerSupabase } = await import("@/lib/supabase/server");
  const supabase = await createServerSupabase();
  const { data } = await supabase
    .from("public_products")
    .select("*")
    .eq("slug", slug)
    .maybeSingle();
  return data ? mapProduct(data) : null;
}

/**
 * REP-GATED read: full product rows including SKU/UPC/case data. In real mode
 * RLS on the base `products` table restricts this to rep + admin roles.
 */
export async function getRepProducts(): Promise<Product[]> {
  if (!isSupabaseConfigured) return mock.products;
  const { createServerSupabase } = await import("@/lib/supabase/server");
  const supabase = await createServerSupabase();
  const { data } = await supabase.from("products").select("*").order("name");
  return (data ?? []).map(mapProduct);
}

/* ── videos ────────────────────────────────────────────────────────── */

/** Public videos only — safe for the unauthenticated video hub. */
export async function getPublicVideos(): Promise<Video[]> {
  if (!isSupabaseConfigured) {
    return mock.videos.filter((v) => v.access === "public");
  }
  const { createServerSupabase } = await import("@/lib/supabase/server");
  const supabase = await createServerSupabase();
  const { data } = await supabase
    .from("videos")
    .select("*")
    .eq("access", "public");
  return (data ?? []).map(mapVideo);
}

/** Rep-gated training videos. RLS blocks these for non-reps in real mode. */
export async function getTrainingVideos(): Promise<Video[]> {
  if (!isSupabaseConfigured) {
    return mock.videos.filter((v) => v.access === "rep");
  }
  const { createServerSupabase } = await import("@/lib/supabase/server");
  const supabase = await createServerSupabase();
  const { data } = await supabase.from("videos").select("*").eq("access", "rep");
  return (data ?? []).map(mapVideo);
}

export async function getAllVideos(): Promise<Video[]> {
  if (!isSupabaseConfigured) return mock.videos;
  const { createServerSupabase } = await import("@/lib/supabase/server");
  const supabase = await createServerSupabase();
  const { data } = await supabase.from("videos").select("*");
  return (data ?? []).map(mapVideo);
}

/* ── assets (sell sheets / POS) ────────────────────────────────────── */

export async function getAssets(): Promise<Asset[]> {
  if (!isSupabaseConfigured) return mock.assets;
  const { createServerSupabase } = await import("@/lib/supabase/server");
  const supabase = await createServerSupabase();
  const { data } = await supabase.from("assets").select("*").order("title");
  return (data ?? []).map(mapAsset);
}

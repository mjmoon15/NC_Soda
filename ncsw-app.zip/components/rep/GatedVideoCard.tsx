import { Clock, Lock, Play } from "lucide-react";
import { Badge } from "@/components/ui/Badge";
import type { Video } from "@/lib/types";
import { formatDuration } from "@/lib/utils";
import styles from "./GatedVideoCard.module.css";

/**
 * A rep-only training video. These have no youtubeId — they stream from
 * Supabase Storage via a signed URL in real mode. In demo mode there is no
 * playable source, so we render a styled placeholder with a (non-functional)
 * play affordance rather than attempting to load anything.
 */
export function GatedVideoCard({ video }: { video: Video }) {
  return (
    <article className={`card ${styles.card}`} style={{ padding: 0 }}>
      <div className={`dot-grid ${styles.thumb}`}>
        <span className={styles.lock}>
          <Lock size={12} />
          Rep-only
        </span>
        <span className={styles.play} aria-hidden>
          <Play size={22} fill="currentColor" />
        </span>
        <span className={styles.duration}>
          <Clock size={12} />
          {formatDuration(video.durationSeconds)}
        </span>
      </div>

      <div className={`card-pad stack ${styles.body}`}>
        <strong className={styles.title}>{video.title}</strong>
        <p className="muted" style={{ fontSize: "0.88rem" }}>
          {video.description}
        </p>
        <Badge tone="citrus" className={styles.statusBadge}>
          streams via signed URL once Supabase Storage is connected
        </Badge>
      </div>
    </article>
  );
}
